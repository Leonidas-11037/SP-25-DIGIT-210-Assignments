var networks = {"networkData-2.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "networkData-2.tsv",
    "name" : "networkData-2.tsv",
    "SUID" : 7774,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "9090",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "smelly",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9090,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "smelly",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -331.43640029588323,
        "y" : -183.253946651457
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9074",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "pivoting",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9074,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "pivoting",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 434.32910204545533,
        "y" : -445.68170097381176
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9048",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "popular",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9048,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "popular",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 218.8930425831977,
        "y" : 729.9295894465156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9044",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "angry",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9044,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "angry",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -201.91834246135795,
        "y" : -305.44793205588326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9040",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "golden",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9040,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "golden",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 434.3291020454576,
        "y" : 503.45947875158913
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9034",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "complete",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9034,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "complete",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 545.785387205628,
        "y" : 116.74066367053751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9028",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "medium",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9028,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "medium",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 187.944562161229,
        "y" : 459.8940264678297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9024",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "light",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9024,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "light",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -277.6426588685499,
        "y" : -100.53610544215167
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9016",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "heavy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9016,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "heavy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 37.39512162468327,
        "y" : 764.5521695508112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9006",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "pleased",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9006,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "pleased",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -512.5994105192372,
        "y" : 438.6877940233387
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9000",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "dry",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 9000,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "dry",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -463.519336378336,
        "y" : 162.38043276821668
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8994",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "inside",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8994,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "inside",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -119.61183147496786,
        "y" : -340.9514952919392
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8984",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "flintlock",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8984,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "flintlock",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -147.0109939350823,
        "y" : 752.9503201508303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8974",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "flustered",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8974,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "flustered",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -563.7087672541725,
        "y" : 366.2823310617375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8966",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "awfull",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8966,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "awfull",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 187.94456216122717,
        "y" : -402.11624869005095
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8958",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "bald",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8958,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "bald",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -179.21079464548848,
        "y" : -94.85721909419976
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8948",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "refined",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8948,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "refined",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -307.6335415920962,
        "y" : -547.6621190295339
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8944",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "filthy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8944,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "filthy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 365.5802587789931,
        "y" : 559.3908113127384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8940",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "naughty",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8940,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "naughty",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -8.888888888892325,
        "y" : -532.6994718285157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8936",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "embarrassed",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8936,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "embarrassed",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -480.56701271891825,
        "y" : -16.150910976616387
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8928",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "surprised",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8928,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "surprised",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -75.26558849604135,
        "y" : -261.9264335842088
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8916",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "notorious",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8916,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "notorious",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -226.34399899414575,
        "y" : -582.9711501229915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8910",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "astronomical",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8910,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "astronomical",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -604.4828794146865,
        "y" : 287.59186664536423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8882",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "curious",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8882,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "curious",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 634.4160889162658,
        "y" : -59.53134511678422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8878",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "giant",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8878,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "giant",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -563.5631649834077,
        "y" : 116.74066367053751
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8870",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "easy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8870,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "easy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 265.9557838910182,
        "y" : -357.0764488245452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8866",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "serious",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8866,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "serious",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 366.76375045014447,
        "y" : -60.14242214021192
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8860",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "artificial",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8860,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "artificial",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -694.2436999449578,
        "y" : 300.2400545502567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8856",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "natural",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8856,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "natural",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -478.74546698837503,
        "y" : 596.8479262851827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8850",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "ready",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8850,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "ready",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 640.4641986147503,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8834",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "existent",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8834,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "existent",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 366.76375045014356,
        "y" : 117.9201999179943
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8830",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "-",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8830,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "-",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 201.64056468357876,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8826",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "non",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8826,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "non",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 218.8930425832009,
        "y" : -672.151811668735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8820",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "courageous",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8820,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "courageous",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -141.00367913580294,
        "y" : -606.8823863733103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8814",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "somethign",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8814,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "somethign",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -542.9911588246914,
        "y" : -144.65145841595654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8808",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "left",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8808,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "left",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -463.51933637833645,
        "y" : -104.60265499043658
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8802",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "fat",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8802,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "fat",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 336.10595162341133,
        "y" : 202.15180992462388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8798",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "3rd",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8798,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "3rd",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 183.4393371222177,
        "y" : 114.51893210353796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8794",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "153rd",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8794,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "153rd",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 386.07858706397974,
        "y" : -593.4802661010574
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8784",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "famous",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8784,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "famous",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 144.02123273041116,
        "y" : -325.59661785618687
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8780",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "recent",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8780,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "recent",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 78.96288589275491,
        "y" : -525.7853872056287
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8776",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "veteran",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8776,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "veteran",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -430.0401311374085,
        "y" : -188.2296667996327
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8770",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "warm",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8770,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "warm",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 286.84939164607476,
        "y" : 277.04277101078173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8766",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "like",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8766,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "like",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 131.98281203645502,
        "y" : 185.3427629218529
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8760",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "waterproof",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8760,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "waterproof",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -634.1622024388121,
        "y" : 204.08225523821943
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8756",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "snowy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8756,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "snowy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -53.20231070594264,
        "y" : -618.9504066909428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8752",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "sunny",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8752,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "sunny",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 208.566221216362,
        "y" : 640.7489279007725
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8748",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "rainy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8748,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "rainy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 164.65145841595313,
        "y" : -505.2133810469129
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8740",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "astonishing",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8740,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "astonishing",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -163.86141981041692,
        "y" : 476.6526108802061
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8730",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "enough",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8730,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "enough",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 528.4468724418734,
        "y" : -475.7029776117213
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8726",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "low",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8726,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "low",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -76.32102272186421,
        "y" : 497.8896814239049
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8720",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "wooden",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8720,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "wooden",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 123.2259013580192,
        "y" : 664.6601641510904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8714",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "impossible",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8714,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "impossible",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 78.9628858927581,
        "y" : 583.5631649834079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8708",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "alien",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8708,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "alien",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -245.80070585447493,
        "y" : 439.23219278674264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8704",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "half",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8704,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "half",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 100.09021252589264,
        "y" : -248.78533298036632
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8700",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "earthling",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8700,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "earthling",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -740.1943090466689,
        "y" : 121.27424807169086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8692",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "similar",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8692,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "similar",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 35.424532928154804,
        "y" : -618.9504066909433
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8684",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "dumb",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8684,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "dumb",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 321.204467399903,
        "y" : -425.44563877466203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8676",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "valuable",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8676,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "valuable",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -319.17738156567793,
        "y" : 386.9808985513607
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8672",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "artistic",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8672,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "artistic",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 177.0944905185711,
        "y" : -204.32689235254088
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8666",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "mammoth",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8666,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "mammoth",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 637.0523757526612,
        "y" : -326.2203263910794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8660",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "amazing",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8660,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "amazing",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 164.65145841595722,
        "y" : 562.9911588246916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8654",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "top",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8654,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "top",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -509.2677821963489,
        "y" : -226.06689164111754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8624",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "technical",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8624,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "technical",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -53.202310705937634,
        "y" : 676.7281844687225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8620",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "braided",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8620,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "braided",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 388.21404920982104,
        "y" : -368.2140492098281
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8614",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "tired",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8614,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "tired",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 430.9937787579547,
        "y" : -147.21356644787215
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8610",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "double",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8610,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "double",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 144.02123273040934,
        "y" : 383.37439563396697
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8606",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "strained",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8606,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "strained",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -8.888888888889596,
        "y" : 151.65361567512423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8600",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "mad",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8600,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "mad",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -652.193866694045,
        "y" : 117.30912289456523
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8594",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "elementary",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8594,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "elementary",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 102.81926666593199,
        "y" : 489.35617768830093
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8590",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "cheap",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8590,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "cheap",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -463.2234165524392,
        "y" : -301.20446739990643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8584",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "least",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8584,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "least",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -319.1773815656784,
        "y" : -329.2031207735806
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8580",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "funky",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8580,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "funky",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -331.43640029588323,
        "y" : 241.0317244292362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8576",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "spanish",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8576,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "spanish",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 237.5733290762787,
        "y" : -139.14620611081568
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8570",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "true",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8570,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "true",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -430.0401311374085,
        "y" : 246.0074445774128
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8560",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "fun",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8560,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "fun",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -141.00367913579748,
        "y" : 664.6601641510908
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8556",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "silly",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8556,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "silly",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 445.44563877465635,
        "y" : -301.20446739991144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8548",
        "degree_layout" : 6,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "shared_name" : "okay",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8548,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "EdgeCount" : 6,
        "name" : "okay",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 221.64950441609744,
        "y" : 338.5556920795095
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8538",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "circular",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8538,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "circular",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 705.0710138002246,
        "y" : -154.4248571740593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8534",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "powerful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8534,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "powerful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -563.7087672541761,
        "y" : -308.50455328395196
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8526",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "tidal",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8526,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "tidal",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -405.9918269876043,
        "y" : -368.21404920982445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8522",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "clear",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8522,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "clear",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -8.888888888889596,
        "y" : 590.4772496062953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8518",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "broken",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8518,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "broken",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 456.37213470942606,
        "y" : -60.7828234399592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8510",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "tough",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8510,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "tough",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -95.69665968994968,
        "y" : 115.69665968994991
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8500",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "raw",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8500,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "raw",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 123.22590135801511,
        "y" : -606.8823863733116
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8490",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "perfect",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8490,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "perfect",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -96.74066367053683,
        "y" : 583.5631649834079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8484",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "kindred",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8484,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "kindred",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -371.6655951216594,
        "y" : 160.92881164275218
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8480",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "armed",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8480,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "armed",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 289.40529146981316,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8474",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "fake",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8474,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "fake",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -381.33942270276066,
        "y" : -264.009448309366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8468",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "ok",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8468,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "ok",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 208.56622121635837,
        "y" : -582.9711501229942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8464",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "occasional",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8464,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "occasional",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -226.3439989941403,
        "y" : 640.748927900773
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8460",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "worth",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8460,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "worth",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 321.2044673999071,
        "y" : 483.22341655243895
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8456",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "own",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8456,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "own",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -245.80070585447538,
        "y" : -381.45441500896254
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8448",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "second",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8448,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "second",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 276.15291798615317,
        "y" : 116.812642046277
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8442",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "female",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8442,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "female",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 728.2289254009843,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8436",
        "degree_layout" : 7,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "shared_name" : "bad",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8436,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 7,
        "EdgeCount" : 7,
        "name" : "bad",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -179.21079464548802,
        "y" : 152.63499687197987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8430",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "wrong",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8430,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "wrong",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -158.03597906824098,
        "y" : -229.44144910280397
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8426",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "cuuuuute",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8426,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "cuuuuute",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -182.42923619373596,
        "y" : 562.9911588246916
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8416",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "accurate",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8416,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "accurate",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 237.57332907627915,
        "y" : 196.92398388859488
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8412",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "handy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8412,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "handy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -740.1943090466689,
        "y" : -63.496470293913944
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8408",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "useful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8408,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "useful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -658.2419763925295,
        "y" : 28.88888888889346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8402",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "scary",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8402,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "scary",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 616.3844246610333,
        "y" : 204.08225523821625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8398",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "interested",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8398,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "interested",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -338.98224517768676,
        "y" : -425.44563877465885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8394",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "odd",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8394,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "odd",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -263.8446694188974,
        "y" : 529.2677821963487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8390",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "third",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8390,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "third",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 464.9347450422815,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8384",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "dangerous",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8384,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "dangerous",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 177.0944905185711,
        "y" : 262.1046701303201
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8380",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "personal",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8380,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "personal",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -694.2436999449569,
        "y" : -242.4622767724793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8374",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "japanese",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8374,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "japanese",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -214.81776878459868,
        "y" : 72.66042354808064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8366",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "brown",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8366,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "brown",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -263.8446694188983,
        "y" : -471.49000441856856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8360",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "various",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8360,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "various",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -163.86141981041783,
        "y" : -418.874833102426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8354",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "weekly",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8354,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "weekly",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -119.61183147496831,
        "y" : 398.7292730697184
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8350",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "current",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8350,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "current",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -131.653615675124,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8346",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "exact",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8346,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "exact",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 705.0710138002237,
        "y" : 212.20263495184304
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8330",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "weirdo",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8330,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "weirdo",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -405.9918269876039,
        "y" : 425.99182698760455
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8318",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "disgusting",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8318,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "disgusting",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -95.69665968994968,
        "y" : -57.918881912170264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8314",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "hungry",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8314,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "hungry",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 637.0523757526589,
        "y" : 383.9981041688627
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8306",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "striped",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8306,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "striped",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -201.9183424613584,
        "y" : 363.2257098336629
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8300",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "relaxing",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8300,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "relaxing",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 525.21338104691,
        "y" : -144.6514584159629
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8296",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "hard",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8296,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "hard",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -76.32102272186557,
        "y" : -440.11190364612526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8292",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "hmmmm",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8292,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "hmmmm",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -392.337403813176,
        "y" : -15.92981466556762
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8286",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "white",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8286,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "white",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -8.888888888890051,
        "y" : -93.87583789734458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8282",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "black",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8282,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "black",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 528.4468724418707,
        "y" : 533.4807553895037
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8278",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "well",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8278,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "well",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -512.5994105192412,
        "y" : -380.9100162455536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8274",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "partial",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8274,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "partial",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 586.7051016369082,
        "y" : 287.5918666453615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8268",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "able",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8268,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "able",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 100.0902125258931,
        "y" : 306.56311075814597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8264",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "german",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8264,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "german",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 13.65654737612158,
        "y" : -444.39806357796283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8258",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "sorry",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8258,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "sorry",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -214.81776878459914,
        "y" : -14.882645770300996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8252",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "damn",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8252,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "damn",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -605.2297275059132,
        "y" : -404.3780915527616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8246",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "different",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8246,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "different",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -452.1068798232409,
        "y" : -445.68170097380585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8242",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "donnnn",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8242,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "donnnn",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 545.9309894763942,
        "y" : 366.28233106173525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8238",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "sound",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8238,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "sound",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -182.42923619373778,
        "y" : -505.21338104691154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8216",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "sharp",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8216,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "sharp",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -652.1938666940459,
        "y" : -59.531345116778766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8208",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "simple",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8208,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "simple",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -371.66559512165895,
        "y" : -103.15103386497253
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8204",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "cold",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8204,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "cold",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 545.7853872056271,
        "y" : -58.96288589276469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8198",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "proud",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8198,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "proud",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 430.9937787579561,
        "y" : 204.99134422564907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8194",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "disrespectful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8194,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "disrespectful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -227.5539961567806,
        "y" : 231.78045820460125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8188",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "young",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8188,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "young",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 35.424532928159806,
        "y" : 676.7281844687225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8184",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "patient",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8184,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "patient",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 386.07858706397656,
        "y" : 651.2580438788389
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8180",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "next",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8180,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "next",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 265.9557838910205,
        "y" : 414.8542266023235
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8174",
        "degree_layout" : 5,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "shared_name" : "much",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8174,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "EdgeCount" : 5,
        "name" : "much",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -30.895209143398915,
        "y" : -180.48726230884836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8170",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "expensive",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8170,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "expensive",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 552.6994718285159,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8164",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "honest",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8164,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "honest",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 389.7169170946163,
        "y" : 285.05728566721996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8154",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "hilarious",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8154,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "hilarious",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -478.7454669883732,
        "y" : -539.0701485074044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8146",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "secondary",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8146,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "secondary",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 289.85576381430974,
        "y" : -547.6621190295375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8142",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "painful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8142,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "painful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -307.6335415920912,
        "y" : 605.4398968073162
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8136",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "former",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8136,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "former",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -463.2234165524387,
        "y" : 358.98224517768654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8132",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "alive",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8132,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "alive",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 334.03340304573567,
        "y" : 355.86463380897453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8126",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "axe",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8126,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "axe",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -158.03597906824098,
        "y" : 287.2192268805836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8118",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "Most",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8118,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "Most",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -634.1622024388139,
        "y" : -146.30447746043296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8112",
        "degree_layout" : 5,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "shared_name" : "high",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8112,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "EdgeCount" : 5,
        "name" : "high",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 494.82163274145887,
        "y" : 438.68779402333735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8108",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "dead",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8108,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "dead",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -96.74066367053956,
        "y" : -525.7853872056278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8104",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "interesting",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8104,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "interesting",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -509.26778219634843,
        "y" : 283.8446694188981
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8098",
        "degree_layout" : 5,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "shared_name" : "special",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8098,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "EdgeCount" : 5,
        "name" : "special",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -273.8185856418445,
        "y" : 309.6979620406139
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8092",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "normal",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8092,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "normal",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -75.26558849604135,
        "y" : 319.7042113619884
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8086",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "stupid",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8086,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "stupid",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 131.98281203645547,
        "y" : -127.56498514407326
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8082",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "nervous",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8082,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "nervous",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 365.58025877899036,
        "y" : -501.61303353496055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8078",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "actual",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8078,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "actual",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -383.35803655677137,
        "y" : 559.3908113127393
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8072",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "long",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8072,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "long",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 286.8493916460761,
        "y" : -219.26499323300027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8064",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "cruel",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8064,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "cruel",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -303.85136971113343,
        "y" : 73.34732951671526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8060",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "correct",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8060,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "correct",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -605.2297275059145,
        "y" : 462.1558693305394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8056",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "last",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8056,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "last",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 13.656547376123399,
        "y" : 502.1758413557425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8050",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "cool",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8050,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "cool",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 289.8557638143129,
        "y" : 605.4398968073158
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8046",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "mysterious",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8046,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "mysterious",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -31.33621799419734,
        "y" : 414.29464546497024
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8040",
        "degree_layout" : 9,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "shared_name" : "weird",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8040,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 9,
        "EdgeCount" : 9,
        "name" : "weird",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 77.91888191217004,
        "y" : -57.918881912170264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8026",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "key",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8026,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "key",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -338.98224517768585,
        "y" : 483.2234165524394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8022",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "entire",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8022,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "entire",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 246.06689164111458,
        "y" : -471.49000441857083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8018",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "frequent",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8018,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "frequent",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 494.82163274145705,
        "y" : -380.9100162455595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8014",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "ridiculous",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8014,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "ridiculous",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -452.1068798232359,
        "y" : 503.4594787515905
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8008",
        "degree_layout" : 6,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "shared_name" : "great",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8008,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 6,
        "EdgeCount" : 6,
        "name" : "great",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 13.402663125601975,
        "y" : -268.57120044185626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8004",
        "degree_layout" : 13,
        "Eccentricity" : 1,
        "Outdegree" : 13,
        "shared_name" : "many",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8004,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 13,
        "EdgeCount" : 13,
        "name" : "many",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 113.87583789734435,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8000",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "dreadful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 8000,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "dreadful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -227.55399615678016,
        "y" : -174.0026804268216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7996",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "terrible",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7996,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "terrible",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -480.56701271891825,
        "y" : 73.92868875439694
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7990",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "nice",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7990,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "nice",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -604.4828794146893,
        "y" : -229.81408886757777
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7986",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "gigantic",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7986,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "gigantic",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 545.9309894763928,
        "y" : -308.5045532839579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7982",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "wonderful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7982,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "wonderful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -381.3394227027602,
        "y" : 321.7872260871461
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7978",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "straight",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7978,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "straight",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 491.49000441856924,
        "y" : 283.84466941889764
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7974",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "strong",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7974,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "strong",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 102.81926666593017,
        "y" : -431.57839991052174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7970",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "big",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7970,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "big",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -31.33621799419643,
        "y" : -356.5168676871906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7966",
        "degree_layout" : 13,
        "Eccentricity" : 1,
        "Outdegree" : 13,
        "shared_name" : "old",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7966,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 13,
        "EdgeCount" : 13,
        "name" : "old",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 77.91888191217049,
        "y" : 115.69665968994991
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7960",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "crazy",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7960,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "crazy",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -322.7383896572269,
        "y" : 695.8530281129913
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7956",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "glad",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7956,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "glad",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -383.35803655677637,
        "y" : -501.613033534956
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7948",
        "degree_layout" : 9,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "shared_name" : "good",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7948,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 9,
        "EdgeCount" : 9,
        "name" : "good",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 13.402663125601975,
        "y" : 326.3489782196359
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7944",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "new",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7944,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "new",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -114.153615675124,
        "y" : 211.21274392750388
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7938",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "unyielding",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7938,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "unyielding",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 58.14953680891631,
        "y" : -351.304915986864
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7934",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "certain",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7934,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "certain",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -114.153615675124,
        "y" : -153.43496614972423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7930",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "tall",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7930,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "tall",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -322.73838965722507,
        "y" : -638.075250335213
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7926",
        "degree_layout" : 16,
        "Eccentricity" : 1,
        "Outdegree" : 16,
        "shared_name" : "right",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7926,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 16,
        "EdgeCount" : 16,
        "name" : "right",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -392.337403813176,
        "y" : 73.70759244334727
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7922",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "final",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7922,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "final",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 586.7051016369073,
        "y" : -229.81408886758413
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7918",
        "degree_layout" : 4,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "shared_name" : "careful",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7918,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 4,
        "EdgeCount" : 4,
        "name" : "careful",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 456.372134709427,
        "y" : 118.56060121773521
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7914",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "sudden",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7914,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "sudden",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 445.4456387746595,
        "y" : 358.9822451776861
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7910",
        "degree_layout" : 9,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "shared_name" : "little",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7910,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 9,
        "EdgeCount" : 9,
        "name" : "little",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -30.89520914339846,
        "y" : 238.265040086628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7906",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "favorite",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7906,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "favorite",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 221.64950441609926,
        "y" : -280.77791430172897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7902",
        "degree_layout" : 8,
        "Eccentricity" : 1,
        "Outdegree" : 8,
        "shared_name" : "first",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7902,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 8,
        "EdgeCount" : 8,
        "name" : "first",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 56.168290081474424,
        "y" : 229.11429758104418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7898",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "legendary",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7898,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "legendary",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -147.01099393507957,
        "y" : -695.1725423730511
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7894",
        "degree_layout" : 5,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "shared_name" : "more",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7894,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "EdgeCount" : 5,
        "name" : "more",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -303.85136971113343,
        "y" : -15.56955173893607
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7890",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "pointless",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7890,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "pointless",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 616.3844246610329,
        "y" : -146.30447746043842
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7886",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "decorative",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7886,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "decorative",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -542.9911588246914,
        "y" : 202.42923619373664
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7882",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "deep",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7882,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "deep",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 388.2140492098247,
        "y" : 425.9918269876041
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7878",
        "degree_layout" : 5,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "shared_name" : "real",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7878,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 5,
        "EdgeCount" : 5,
        "name" : "real",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -273.8185856418445,
        "y" : -251.9201842628347
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7874",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "o:[decorative",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7874,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "o:[decorative",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 336.1059516234127,
        "y" : -144.37403214684196
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7870",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "fine",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7870,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "fine",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 56.168290081474424,
        "y" : -171.33651980326454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7866",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "chinese",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7866,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "chinese",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 37.39512162468645,
        "y" : -706.7743917730311
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7862",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "full",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7862,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "full",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 525.2133810469122,
        "y" : 202.4292361937362
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7858",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "funny",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7858,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "funny",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 491.4900044185665,
        "y" : -226.06689164112345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7854",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "cut",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7854,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "cut",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -570.4772496062951,
        "y" : 28.88888888889028
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7850",
        "degree_layout" : 13,
        "Eccentricity" : 1,
        "Outdegree" : 13,
        "shared_name" : "same",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7850,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 13,
        "EdgeCount" : 13,
        "name" : "same",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 276.1529179861527,
        "y" : -59.03486426849781
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7846",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "short",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7846,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "short",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 58.1495368089154,
        "y" : 409.0826937646441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7842",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "main",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7842,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "main",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 377.1700182560471,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7838",
        "degree_layout" : 3,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "shared_name" : "cute",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7838,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 3,
        "EdgeCount" : 3,
        "name" : "cute",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 183.4393371222177,
        "y" : -56.741154325758316
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7834",
        "degree_layout" : 7,
        "Eccentricity" : 1,
        "Outdegree" : 7,
        "shared_name" : "other",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7834,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 7,
        "EdgeCount" : 7,
        "name" : "other",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -277.64265886855037,
        "y" : 158.31388321993086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7830",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "upper",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7830,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "upper",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 389.7169170946149,
        "y" : -227.27950788944304
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7826",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "bottom",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7826,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "bottom",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 634.4160889162658,
        "y" : 117.30912289456205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7822",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "small",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7822,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "small",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : -563.5631649834077,
        "y" : -58.96288589275741
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7818",
        "degree_layout" : 2,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "shared_name" : "whole",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7818,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 1,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 2,
        "EdgeCount" : 2,
        "name" : "whole",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 246.06689164111822,
        "y" : 529.2677821963487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7804",
        "degree_layout" : 426,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "shared_name" : "ADJ",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 426,
        "SUID" : 7804,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "ClosenessCentrality" : 0.0,
        "Degree" : 426,
        "PartnerOfMultiEdgedNodePairs" : 75,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 1.0,
        "Stress" : 0,
        "unit" : "vol-9",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 426,
        "EdgeCount" : 426,
        "synsetCount" : 4,
        "name" : "ADJ",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -8.888888888889596,
        "y" : 28.888888888889824
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7802",
        "degree_layout" : 1,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "shared_name" : "sixth",
        "TopologicalCoefficient" : 0.0,
        "Indegree" : 0,
        "SUID" : 7802,
        "SelfLoops" : 0,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "ClosenessCentrality" : 1.0,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : 0.9953704705246079,
        "Stress" : 0,
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "EdgeCount" : 1,
        "name" : "sixth",
        "IsSingleNode" : false,
        "NeighborhoodConnectivity" : 215.0
      },
      "position" : {
        "x" : 334.03340304573385,
        "y" : -298.0868560311967
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "9092",
        "source" : "9090",
        "target" : "7804",
        "EdgeBetweenness" : 36.0,
        "shared_name" : "smelly (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "smelly (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9092,
        "BEND_MAP_ID" : 9092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9076",
        "source" : "9074",
        "target" : "7804",
        "EdgeBetweenness" : 43.0,
        "shared_name" : "pivoting (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "pivoting (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9076,
        "BEND_MAP_ID" : 9076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9050",
        "source" : "9048",
        "target" : "7804",
        "EdgeBetweenness" : 51.0,
        "shared_name" : "popular (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "popular (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9050,
        "BEND_MAP_ID" : 9050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9060",
        "source" : "9044",
        "target" : "7804",
        "EdgeBetweenness" : 54.0,
        "shared_name" : "angry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "angry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9060,
        "BEND_MAP_ID" : 9060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9046",
        "source" : "9044",
        "target" : "7804",
        "EdgeBetweenness" : 54.0,
        "shared_name" : "angry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "angry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9046,
        "BEND_MAP_ID" : 9046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9052",
        "source" : "9040",
        "target" : "7804",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "golden (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "golden (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9052,
        "BEND_MAP_ID" : 9052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9042",
        "source" : "9040",
        "target" : "7804",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "golden (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "golden (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9042,
        "BEND_MAP_ID" : 9042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9036",
        "source" : "9034",
        "target" : "7804",
        "EdgeBetweenness" : 60.0,
        "shared_name" : "complete (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "complete (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9036,
        "BEND_MAP_ID" : 9036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9030",
        "source" : "9028",
        "target" : "7804",
        "EdgeBetweenness" : 64.0,
        "shared_name" : "medium (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "medium (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9030,
        "BEND_MAP_ID" : 9030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9032",
        "source" : "9024",
        "target" : "7804",
        "EdgeBetweenness" : 66.0,
        "shared_name" : "light (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9032,
        "BEND_MAP_ID" : 9032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9026",
        "source" : "9024",
        "target" : "7804",
        "EdgeBetweenness" : 66.0,
        "shared_name" : "light (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "light (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9026,
        "BEND_MAP_ID" : 9026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9018",
        "source" : "9016",
        "target" : "7804",
        "EdgeBetweenness" : 69.0,
        "shared_name" : "heavy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "heavy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9018,
        "BEND_MAP_ID" : 9018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9008",
        "source" : "9006",
        "target" : "7804",
        "EdgeBetweenness" : 74.0,
        "shared_name" : "pleased (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "pleased (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9008,
        "BEND_MAP_ID" : 9008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9002",
        "source" : "9000",
        "target" : "7804",
        "EdgeBetweenness" : 77.0,
        "shared_name" : "dry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "dry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9002,
        "BEND_MAP_ID" : 9002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8996",
        "source" : "8994",
        "target" : "7804",
        "EdgeBetweenness" : 81.0,
        "shared_name" : "inside (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "inside (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8996,
        "BEND_MAP_ID" : 8996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8988",
        "source" : "8984",
        "target" : "7804",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "flintlock (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "flintlock (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8988,
        "BEND_MAP_ID" : 8988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8986",
        "source" : "8984",
        "target" : "7804",
        "EdgeBetweenness" : 86.0,
        "shared_name" : "flintlock (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "flintlock (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8986,
        "BEND_MAP_ID" : 8986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8976",
        "source" : "8974",
        "target" : "7804",
        "EdgeBetweenness" : 90.0,
        "shared_name" : "flustered (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "flustered (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8976,
        "BEND_MAP_ID" : 8976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8968",
        "source" : "8966",
        "target" : "7804",
        "EdgeBetweenness" : 95.0,
        "shared_name" : "awfull (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "awfull (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8968,
        "BEND_MAP_ID" : 8968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8964",
        "source" : "8958",
        "target" : "7804",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "bald (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bald (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8964,
        "BEND_MAP_ID" : 8964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8960",
        "source" : "8958",
        "target" : "7804",
        "EdgeBetweenness" : 99.0,
        "shared_name" : "bald (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bald (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8960,
        "BEND_MAP_ID" : 8960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8950",
        "source" : "8948",
        "target" : "7804",
        "EdgeBetweenness" : 103.0,
        "shared_name" : "refined (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "refined (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8950,
        "BEND_MAP_ID" : 8950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8946",
        "source" : "8944",
        "target" : "7804",
        "EdgeBetweenness" : 106.0,
        "shared_name" : "filthy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "filthy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8946,
        "BEND_MAP_ID" : 8946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8942",
        "source" : "8940",
        "target" : "7804",
        "EdgeBetweenness" : 109.0,
        "shared_name" : "naughty (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "naughty (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8942,
        "BEND_MAP_ID" : 8942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8938",
        "source" : "8936",
        "target" : "7804",
        "EdgeBetweenness" : 112.0,
        "shared_name" : "embarrassed (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "embarrassed (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8938,
        "BEND_MAP_ID" : 8938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8930",
        "source" : "8928",
        "target" : "7804",
        "EdgeBetweenness" : 116.0,
        "shared_name" : "surprised (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "surprised (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8930,
        "BEND_MAP_ID" : 8930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8918",
        "source" : "8916",
        "target" : "7804",
        "EdgeBetweenness" : 122.0,
        "shared_name" : "notorious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "notorious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8918,
        "BEND_MAP_ID" : 8918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8912",
        "source" : "8910",
        "target" : "7804",
        "EdgeBetweenness" : 127.0,
        "shared_name" : "astronomical (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "astronomical (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8912,
        "BEND_MAP_ID" : 8912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8884",
        "source" : "8882",
        "target" : "7804",
        "EdgeBetweenness" : 140.0,
        "shared_name" : "curious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "curious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8884,
        "BEND_MAP_ID" : 8884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8880",
        "source" : "8878",
        "target" : "7804",
        "EdgeBetweenness" : 143.0,
        "shared_name" : "giant (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "giant (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8880,
        "BEND_MAP_ID" : 8880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8872",
        "source" : "8870",
        "target" : "7804",
        "EdgeBetweenness" : 146.0,
        "shared_name" : "easy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "easy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8872,
        "BEND_MAP_ID" : 8872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8868",
        "source" : "8866",
        "target" : "7804",
        "EdgeBetweenness" : 150.0,
        "shared_name" : "serious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "serious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8868,
        "BEND_MAP_ID" : 8868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8862",
        "source" : "8860",
        "target" : "7804",
        "EdgeBetweenness" : 153.0,
        "shared_name" : "artificial (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "artificial (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8862,
        "BEND_MAP_ID" : 8862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8858",
        "source" : "8856",
        "target" : "7804",
        "EdgeBetweenness" : 156.0,
        "shared_name" : "natural (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "natural (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8858,
        "BEND_MAP_ID" : 8858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8852",
        "source" : "8850",
        "target" : "7804",
        "EdgeBetweenness" : 159.0,
        "shared_name" : "ready (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "ready (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8852,
        "BEND_MAP_ID" : 8852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8836",
        "source" : "8834",
        "target" : "7804",
        "EdgeBetweenness" : 163.0,
        "shared_name" : "existent (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "existent (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8836,
        "BEND_MAP_ID" : 8836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8832",
        "source" : "8830",
        "target" : "7804",
        "EdgeBetweenness" : 165.0,
        "shared_name" : "- (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "- (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8832,
        "BEND_MAP_ID" : 8832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8828",
        "source" : "8826",
        "target" : "7804",
        "EdgeBetweenness" : 169.0,
        "shared_name" : "non (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "non (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8828,
        "BEND_MAP_ID" : 8828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8824",
        "source" : "8820",
        "target" : "7804",
        "EdgeBetweenness" : 170.0,
        "shared_name" : "courageous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "courageous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8824,
        "BEND_MAP_ID" : 8824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8822",
        "source" : "8820",
        "target" : "7804",
        "EdgeBetweenness" : 170.0,
        "shared_name" : "courageous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "courageous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8822,
        "BEND_MAP_ID" : 8822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8816",
        "source" : "8814",
        "target" : "7804",
        "EdgeBetweenness" : 172.0,
        "shared_name" : "somethign (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "somethign (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8816,
        "BEND_MAP_ID" : 8816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9080",
        "source" : "8808",
        "target" : "7804",
        "EdgeBetweenness" : 175.0,
        "shared_name" : "left (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "left (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9080,
        "BEND_MAP_ID" : 9080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9070",
        "source" : "8808",
        "target" : "7804",
        "EdgeBetweenness" : 175.0,
        "shared_name" : "left (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "left (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9070,
        "BEND_MAP_ID" : 9070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8810",
        "source" : "8808",
        "target" : "7804",
        "EdgeBetweenness" : 175.0,
        "shared_name" : "left (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "left (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8810,
        "BEND_MAP_ID" : 8810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8804",
        "source" : "8802",
        "target" : "7804",
        "EdgeBetweenness" : 177.0,
        "shared_name" : "fat (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fat (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8804,
        "BEND_MAP_ID" : 8804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8800",
        "source" : "8798",
        "target" : "7804",
        "EdgeBetweenness" : 179.0,
        "shared_name" : "3rd (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "3rd (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8800,
        "BEND_MAP_ID" : 8800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8796",
        "source" : "8794",
        "target" : "7804",
        "EdgeBetweenness" : 181.0,
        "shared_name" : "153rd (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "153rd (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8796,
        "BEND_MAP_ID" : 8796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8932",
        "source" : "8784",
        "target" : "7804",
        "EdgeBetweenness" : 184.0,
        "shared_name" : "famous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "famous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8932,
        "BEND_MAP_ID" : 8932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8786",
        "source" : "8784",
        "target" : "7804",
        "EdgeBetweenness" : 184.0,
        "shared_name" : "famous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "famous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8786,
        "BEND_MAP_ID" : 8786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8782",
        "source" : "8780",
        "target" : "7804",
        "EdgeBetweenness" : 186.0,
        "shared_name" : "recent (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "recent (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8782,
        "BEND_MAP_ID" : 8782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8778",
        "source" : "8776",
        "target" : "7804",
        "EdgeBetweenness" : 188.0,
        "shared_name" : "veteran (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "veteran (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8778,
        "BEND_MAP_ID" : 8778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8772",
        "source" : "8770",
        "target" : "7804",
        "EdgeBetweenness" : 189.0,
        "shared_name" : "warm (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "warm (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8772,
        "BEND_MAP_ID" : 8772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8768",
        "source" : "8766",
        "target" : "7804",
        "EdgeBetweenness" : 191.0,
        "shared_name" : "like (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "like (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8768,
        "BEND_MAP_ID" : 8768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8762",
        "source" : "8760",
        "target" : "7804",
        "EdgeBetweenness" : 193.0,
        "shared_name" : "waterproof (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "waterproof (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8762,
        "BEND_MAP_ID" : 8762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8758",
        "source" : "8756",
        "target" : "7804",
        "EdgeBetweenness" : 195.0,
        "shared_name" : "snowy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "snowy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8758,
        "BEND_MAP_ID" : 8758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8754",
        "source" : "8752",
        "target" : "7804",
        "EdgeBetweenness" : 197.0,
        "shared_name" : "sunny (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sunny (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8754,
        "BEND_MAP_ID" : 8754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8750",
        "source" : "8748",
        "target" : "7804",
        "EdgeBetweenness" : 199.0,
        "shared_name" : "rainy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "rainy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8750,
        "BEND_MAP_ID" : 8750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8742",
        "source" : "8740",
        "target" : "7804",
        "EdgeBetweenness" : 200.0,
        "shared_name" : "astonishing (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "astonishing (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8742,
        "BEND_MAP_ID" : 8742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8732",
        "source" : "8730",
        "target" : "7804",
        "EdgeBetweenness" : 201.0,
        "shared_name" : "enough (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "enough (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8732,
        "BEND_MAP_ID" : 8732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8806",
        "source" : "8726",
        "target" : "7804",
        "EdgeBetweenness" : 203.0,
        "shared_name" : "low (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "low (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8806,
        "BEND_MAP_ID" : 8806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8744",
        "source" : "8726",
        "target" : "7804",
        "EdgeBetweenness" : 203.0,
        "shared_name" : "low (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "low (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8744,
        "BEND_MAP_ID" : 8744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8728",
        "source" : "8726",
        "target" : "7804",
        "EdgeBetweenness" : 203.0,
        "shared_name" : "low (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "low (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8728,
        "BEND_MAP_ID" : 8728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8722",
        "source" : "8720",
        "target" : "7804",
        "EdgeBetweenness" : 205.0,
        "shared_name" : "wooden (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wooden (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8722,
        "BEND_MAP_ID" : 8722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8716",
        "source" : "8714",
        "target" : "7804",
        "EdgeBetweenness" : 207.0,
        "shared_name" : "impossible (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "impossible (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8716,
        "BEND_MAP_ID" : 8716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8710",
        "source" : "8708",
        "target" : "7804",
        "EdgeBetweenness" : 209.0,
        "shared_name" : "alien (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "alien (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8710,
        "BEND_MAP_ID" : 8710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8706",
        "source" : "8704",
        "target" : "7804",
        "EdgeBetweenness" : 211.0,
        "shared_name" : "half (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "half (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8706,
        "BEND_MAP_ID" : 8706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8702",
        "source" : "8700",
        "target" : "7804",
        "EdgeBetweenness" : 212.0,
        "shared_name" : "earthling (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "earthling (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8702,
        "BEND_MAP_ID" : 8702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8694",
        "source" : "8692",
        "target" : "7804",
        "EdgeBetweenness" : 215.0,
        "shared_name" : "similar (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "similar (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8694,
        "BEND_MAP_ID" : 8694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8686",
        "source" : "8684",
        "target" : "7804",
        "EdgeBetweenness" : 2.0,
        "shared_name" : "dumb (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "dumb (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8686,
        "BEND_MAP_ID" : 8686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8678",
        "source" : "8676",
        "target" : "7804",
        "EdgeBetweenness" : 5.0,
        "shared_name" : "valuable (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "valuable (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8678,
        "BEND_MAP_ID" : 8678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8674",
        "source" : "8672",
        "target" : "7804",
        "EdgeBetweenness" : 6.0,
        "shared_name" : "artistic (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "artistic (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8674,
        "BEND_MAP_ID" : 8674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8668",
        "source" : "8666",
        "target" : "7804",
        "EdgeBetweenness" : 8.0,
        "shared_name" : "mammoth (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mammoth (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8668,
        "BEND_MAP_ID" : 8668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8846",
        "source" : "8660",
        "target" : "7804",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "amazing (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "amazing (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8846,
        "BEND_MAP_ID" : 8846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8812",
        "source" : "8660",
        "target" : "7804",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "amazing (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "amazing (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8812,
        "BEND_MAP_ID" : 8812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8662",
        "source" : "8660",
        "target" : "7804",
        "EdgeBetweenness" : 9.0,
        "shared_name" : "amazing (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "amazing (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8662,
        "BEND_MAP_ID" : 8662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8656",
        "source" : "8654",
        "target" : "7804",
        "EdgeBetweenness" : 12.0,
        "shared_name" : "top (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "top (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8656,
        "BEND_MAP_ID" : 8656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8626",
        "source" : "8624",
        "target" : "7804",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "technical (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "technical (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8626,
        "BEND_MAP_ID" : 8626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8632",
        "source" : "8620",
        "target" : "7804",
        "EdgeBetweenness" : 20.0,
        "shared_name" : "braided (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "braided (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8632,
        "BEND_MAP_ID" : 8632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8622",
        "source" : "8620",
        "target" : "7804",
        "EdgeBetweenness" : 20.0,
        "shared_name" : "braided (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "braided (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8622,
        "BEND_MAP_ID" : 8622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8616",
        "source" : "8614",
        "target" : "7804",
        "EdgeBetweenness" : 22.0,
        "shared_name" : "tired (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "tired (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8616,
        "BEND_MAP_ID" : 8616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8612",
        "source" : "8610",
        "target" : "7804",
        "EdgeBetweenness" : 24.0,
        "shared_name" : "double (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "double (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8612,
        "BEND_MAP_ID" : 8612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8608",
        "source" : "8606",
        "target" : "7804",
        "EdgeBetweenness" : 25.0,
        "shared_name" : "strained (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "strained (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8608,
        "BEND_MAP_ID" : 8608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8604",
        "source" : "8600",
        "target" : "7804",
        "EdgeBetweenness" : 27.0,
        "shared_name" : "mad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8604,
        "BEND_MAP_ID" : 8604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8602",
        "source" : "8600",
        "target" : "7804",
        "EdgeBetweenness" : 27.0,
        "shared_name" : "mad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8602,
        "BEND_MAP_ID" : 8602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8934",
        "source" : "8594",
        "target" : "7804",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "elementary (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "elementary (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8934,
        "BEND_MAP_ID" : 8934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8596",
        "source" : "8594",
        "target" : "7804",
        "EdgeBetweenness" : 30.0,
        "shared_name" : "elementary (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "elementary (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8596,
        "BEND_MAP_ID" : 8596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8894",
        "source" : "8590",
        "target" : "7804",
        "EdgeBetweenness" : 32.0,
        "shared_name" : "cheap (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cheap (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8894,
        "BEND_MAP_ID" : 8894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8592",
        "source" : "8590",
        "target" : "7804",
        "EdgeBetweenness" : 32.0,
        "shared_name" : "cheap (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cheap (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8592,
        "BEND_MAP_ID" : 8592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8586",
        "source" : "8584",
        "target" : "7804",
        "EdgeBetweenness" : 33.0,
        "shared_name" : "least (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "least (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8586,
        "BEND_MAP_ID" : 8586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8582",
        "source" : "8580",
        "target" : "7804",
        "EdgeBetweenness" : 35.0,
        "shared_name" : "funky (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "funky (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8582,
        "BEND_MAP_ID" : 8582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8578",
        "source" : "8576",
        "target" : "7804",
        "EdgeBetweenness" : 38.0,
        "shared_name" : "spanish (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "spanish (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8578,
        "BEND_MAP_ID" : 8578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9066",
        "source" : "8570",
        "target" : "7804",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "true (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "true (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9066,
        "BEND_MAP_ID" : 9066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8952",
        "source" : "8570",
        "target" : "7804",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "true (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "true (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8952,
        "BEND_MAP_ID" : 8952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8664",
        "source" : "8570",
        "target" : "7804",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "true (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "true (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8664,
        "BEND_MAP_ID" : 8664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8572",
        "source" : "8570",
        "target" : "7804",
        "EdgeBetweenness" : 40.0,
        "shared_name" : "true (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "true (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8572,
        "BEND_MAP_ID" : 8572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8670",
        "source" : "8560",
        "target" : "7804",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "fun (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fun (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8670,
        "BEND_MAP_ID" : 8670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8562",
        "source" : "8560",
        "target" : "7804",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "fun (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fun (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8562,
        "BEND_MAP_ID" : 8562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8558",
        "source" : "8556",
        "target" : "7804",
        "EdgeBetweenness" : 46.0,
        "shared_name" : "silly (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "silly (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8558,
        "BEND_MAP_ID" : 8558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8978",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8978,
        "BEND_MAP_ID" : 8978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8922",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8922,
        "BEND_MAP_ID" : 8922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8644",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8644,
        "BEND_MAP_ID" : 8644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8630",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8630,
        "BEND_MAP_ID" : 8630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8628",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8628,
        "BEND_MAP_ID" : 8628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8550",
        "source" : "8548",
        "target" : "7804",
        "EdgeBetweenness" : 48.0,
        "shared_name" : "okay (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "okay (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8550,
        "BEND_MAP_ID" : 8550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8540",
        "source" : "8538",
        "target" : "7804",
        "EdgeBetweenness" : 50.0,
        "shared_name" : "circular (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "circular (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8540,
        "BEND_MAP_ID" : 8540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8536",
        "source" : "8534",
        "target" : "7804",
        "EdgeBetweenness" : 52.0,
        "shared_name" : "powerful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "powerful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8536,
        "BEND_MAP_ID" : 8536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8528",
        "source" : "8526",
        "target" : "7804",
        "EdgeBetweenness" : 57.0,
        "shared_name" : "tidal (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "tidal (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8528,
        "BEND_MAP_ID" : 8528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8524",
        "source" : "8522",
        "target" : "7804",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "clear (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "clear (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8524,
        "BEND_MAP_ID" : 8524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8520",
        "source" : "8518",
        "target" : "7804",
        "EdgeBetweenness" : 62.0,
        "shared_name" : "broken (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "broken (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8520,
        "BEND_MAP_ID" : 8520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8512",
        "source" : "8510",
        "target" : "7804",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "tough (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "tough (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8512,
        "BEND_MAP_ID" : 8512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8502",
        "source" : "8500",
        "target" : "7804",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "raw (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "raw (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8502,
        "BEND_MAP_ID" : 8502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8492",
        "source" : "8490",
        "target" : "7804",
        "EdgeBetweenness" : 76.0,
        "shared_name" : "perfect (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "perfect (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8492,
        "BEND_MAP_ID" : 8492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8998",
        "source" : "8484",
        "target" : "7804",
        "EdgeBetweenness" : 79.0,
        "shared_name" : "kindred (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "kindred (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8998,
        "BEND_MAP_ID" : 8998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8486",
        "source" : "8484",
        "target" : "7804",
        "EdgeBetweenness" : 79.0,
        "shared_name" : "kindred (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "kindred (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8486,
        "BEND_MAP_ID" : 8486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8482",
        "source" : "8480",
        "target" : "7804",
        "EdgeBetweenness" : 82.0,
        "shared_name" : "armed (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "armed (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8482,
        "BEND_MAP_ID" : 8482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8618",
        "source" : "8474",
        "target" : "7804",
        "EdgeBetweenness" : 84.0,
        "shared_name" : "fake (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fake (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8618,
        "BEND_MAP_ID" : 8618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8476",
        "source" : "8474",
        "target" : "7804",
        "EdgeBetweenness" : 84.0,
        "shared_name" : "fake (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fake (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8476,
        "BEND_MAP_ID" : 8476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8470",
        "source" : "8468",
        "target" : "7804",
        "EdgeBetweenness" : 88.0,
        "shared_name" : "ok (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "ok (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8470,
        "BEND_MAP_ID" : 8470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8466",
        "source" : "8464",
        "target" : "7804",
        "EdgeBetweenness" : 89.0,
        "shared_name" : "occasional (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "occasional (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8466,
        "BEND_MAP_ID" : 8466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8876",
        "source" : "8460",
        "target" : "7804",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "worth (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "worth (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8876,
        "BEND_MAP_ID" : 8876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8462",
        "source" : "8460",
        "target" : "7804",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "worth (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "worth (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8462,
        "BEND_MAP_ID" : 8462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8458",
        "source" : "8456",
        "target" : "7804",
        "EdgeBetweenness" : 94.0,
        "shared_name" : "own (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "own (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8458,
        "BEND_MAP_ID" : 8458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8842",
        "source" : "8448",
        "target" : "7804",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "second (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "second (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8842,
        "BEND_MAP_ID" : 8842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8450",
        "source" : "8448",
        "target" : "7804",
        "EdgeBetweenness" : 97.0,
        "shared_name" : "second (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "second (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8450,
        "BEND_MAP_ID" : 8450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8444",
        "source" : "8442",
        "target" : "7804",
        "EdgeBetweenness" : 101.0,
        "shared_name" : "female (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "female (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8444,
        "BEND_MAP_ID" : 8444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9088",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9088,
        "BEND_MAP_ID" : 9088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8898",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8898,
        "BEND_MAP_ID" : 8898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8746",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8746,
        "BEND_MAP_ID" : 8746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8506",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8506,
        "BEND_MAP_ID" : 8506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8498",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8498,
        "BEND_MAP_ID" : 8498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8496",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8496,
        "BEND_MAP_ID" : 8496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8438",
        "source" : "8436",
        "target" : "7804",
        "EdgeBetweenness" : 104.0,
        "shared_name" : "bad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8438,
        "BEND_MAP_ID" : 8438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9072",
        "source" : "8430",
        "target" : "7804",
        "EdgeBetweenness" : 108.0,
        "shared_name" : "wrong (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wrong (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9072,
        "BEND_MAP_ID" : 9072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8962",
        "source" : "8430",
        "target" : "7804",
        "EdgeBetweenness" : 108.0,
        "shared_name" : "wrong (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wrong (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8962,
        "BEND_MAP_ID" : 8962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8432",
        "source" : "8430",
        "target" : "7804",
        "EdgeBetweenness" : 108.0,
        "shared_name" : "wrong (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wrong (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8432,
        "BEND_MAP_ID" : 8432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8428",
        "source" : "8426",
        "target" : "7804",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "cuuuuute (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cuuuuute (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8428,
        "BEND_MAP_ID" : 8428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8418",
        "source" : "8416",
        "target" : "7804",
        "EdgeBetweenness" : 115.0,
        "shared_name" : "accurate (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "accurate (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8418,
        "BEND_MAP_ID" : 8418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8414",
        "source" : "8412",
        "target" : "7804",
        "EdgeBetweenness" : 118.0,
        "shared_name" : "handy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "handy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8414,
        "BEND_MAP_ID" : 8414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8410",
        "source" : "8408",
        "target" : "7804",
        "EdgeBetweenness" : 120.0,
        "shared_name" : "useful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "useful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8410,
        "BEND_MAP_ID" : 8410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8404",
        "source" : "8402",
        "target" : "7804",
        "EdgeBetweenness" : 124.0,
        "shared_name" : "scary (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "scary (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8404,
        "BEND_MAP_ID" : 8404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8400",
        "source" : "8398",
        "target" : "7804",
        "EdgeBetweenness" : 126.0,
        "shared_name" : "interested (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "interested (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8400,
        "BEND_MAP_ID" : 8400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8396",
        "source" : "8394",
        "target" : "7804",
        "EdgeBetweenness" : 129.0,
        "shared_name" : "odd (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "odd (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8396,
        "BEND_MAP_ID" : 8396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8924",
        "source" : "8390",
        "target" : "7804",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "third (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "third (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8924,
        "BEND_MAP_ID" : 8924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8392",
        "source" : "8390",
        "target" : "7804",
        "EdgeBetweenness" : 131.0,
        "shared_name" : "third (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "third (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8392,
        "BEND_MAP_ID" : 8392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8386",
        "source" : "8384",
        "target" : "7804",
        "EdgeBetweenness" : 133.0,
        "shared_name" : "dangerous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "dangerous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8386,
        "BEND_MAP_ID" : 8386,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8382",
        "source" : "8380",
        "target" : "7804",
        "EdgeBetweenness" : 135.0,
        "shared_name" : "personal (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "personal (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8382,
        "BEND_MAP_ID" : 8382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9056",
        "source" : "8374",
        "target" : "7804",
        "EdgeBetweenness" : 138.0,
        "shared_name" : "japanese (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "japanese (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9056,
        "BEND_MAP_ID" : 9056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8954",
        "source" : "8374",
        "target" : "7804",
        "EdgeBetweenness" : 138.0,
        "shared_name" : "japanese (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "japanese (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8954,
        "BEND_MAP_ID" : 8954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8376",
        "source" : "8374",
        "target" : "7804",
        "EdgeBetweenness" : 138.0,
        "shared_name" : "japanese (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "japanese (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8376,
        "BEND_MAP_ID" : 8376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8368",
        "source" : "8366",
        "target" : "7804",
        "EdgeBetweenness" : 142.0,
        "shared_name" : "brown (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "brown (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8368,
        "BEND_MAP_ID" : 8368,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8362",
        "source" : "8360",
        "target" : "7804",
        "EdgeBetweenness" : 145.0,
        "shared_name" : "various (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "various (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8362,
        "BEND_MAP_ID" : 8362,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8356",
        "source" : "8354",
        "target" : "7804",
        "EdgeBetweenness" : 149.0,
        "shared_name" : "weekly (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weekly (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8356,
        "BEND_MAP_ID" : 8356,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8352",
        "source" : "8350",
        "target" : "7804",
        "EdgeBetweenness" : 151.0,
        "shared_name" : "current (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "current (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8352,
        "BEND_MAP_ID" : 8352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8348",
        "source" : "8346",
        "target" : "7804",
        "EdgeBetweenness" : 154.0,
        "shared_name" : "exact (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "exact (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8348,
        "BEND_MAP_ID" : 8348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8332",
        "source" : "8330",
        "target" : "7804",
        "EdgeBetweenness" : 161.0,
        "shared_name" : "weirdo (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weirdo (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8332,
        "BEND_MAP_ID" : 8332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8320",
        "source" : "8318",
        "target" : "7804",
        "EdgeBetweenness" : 164.0,
        "shared_name" : "disgusting (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "disgusting (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8320,
        "BEND_MAP_ID" : 8320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8316",
        "source" : "8314",
        "target" : "7804",
        "EdgeBetweenness" : 168.0,
        "shared_name" : "hungry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "hungry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8316,
        "BEND_MAP_ID" : 8316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8324",
        "source" : "8306",
        "target" : "7804",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "striped (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "striped (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8324,
        "BEND_MAP_ID" : 8324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8312",
        "source" : "8306",
        "target" : "7804",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "striped (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "striped (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8312,
        "BEND_MAP_ID" : 8312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8308",
        "source" : "8306",
        "target" : "7804",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "striped (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "striped (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8308,
        "BEND_MAP_ID" : 8308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8302",
        "source" : "8300",
        "target" : "7804",
        "EdgeBetweenness" : 173.0,
        "shared_name" : "relaxing (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "relaxing (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8302,
        "BEND_MAP_ID" : 8302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8566",
        "source" : "8296",
        "target" : "7804",
        "EdgeBetweenness" : 174.0,
        "shared_name" : "hard (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "hard (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8566,
        "BEND_MAP_ID" : 8566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8298",
        "source" : "8296",
        "target" : "7804",
        "EdgeBetweenness" : 174.0,
        "shared_name" : "hard (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "hard (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8298,
        "BEND_MAP_ID" : 8298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8294",
        "source" : "8292",
        "target" : "7804",
        "EdgeBetweenness" : 176.0,
        "shared_name" : "hmmmm (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "hmmmm (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8294,
        "BEND_MAP_ID" : 8294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8288",
        "source" : "8286",
        "target" : "7804",
        "EdgeBetweenness" : 178.0,
        "shared_name" : "white (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "white (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8288,
        "BEND_MAP_ID" : 8288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8284",
        "source" : "8282",
        "target" : "7804",
        "EdgeBetweenness" : 180.0,
        "shared_name" : "black (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "black (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8284,
        "BEND_MAP_ID" : 8284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8280",
        "source" : "8278",
        "target" : "7804",
        "EdgeBetweenness" : 182.0,
        "shared_name" : "well (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "well (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8280,
        "BEND_MAP_ID" : 8280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8276",
        "source" : "8274",
        "target" : "7804",
        "EdgeBetweenness" : 183.0,
        "shared_name" : "partial (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "partial (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8276,
        "BEND_MAP_ID" : 8276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8652",
        "source" : "8268",
        "target" : "7804",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "able (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "able (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8652,
        "BEND_MAP_ID" : 8652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8554",
        "source" : "8268",
        "target" : "7804",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "able (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "able (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8554,
        "BEND_MAP_ID" : 8554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8322",
        "source" : "8268",
        "target" : "7804",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "able (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "able (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8322,
        "BEND_MAP_ID" : 8322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8270",
        "source" : "8268",
        "target" : "7804",
        "EdgeBetweenness" : 185.0,
        "shared_name" : "able (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "able (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8270,
        "BEND_MAP_ID" : 8270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8266",
        "source" : "8264",
        "target" : "7804",
        "EdgeBetweenness" : 187.0,
        "shared_name" : "german (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "german (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8266,
        "BEND_MAP_ID" : 8266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8992",
        "source" : "8258",
        "target" : "7804",
        "EdgeBetweenness" : 190.0,
        "shared_name" : "sorry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sorry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8992,
        "BEND_MAP_ID" : 8992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8688",
        "source" : "8258",
        "target" : "7804",
        "EdgeBetweenness" : 190.0,
        "shared_name" : "sorry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sorry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8688,
        "BEND_MAP_ID" : 8688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8260",
        "source" : "8258",
        "target" : "7804",
        "EdgeBetweenness" : 190.0,
        "shared_name" : "sorry (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sorry (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8260,
        "BEND_MAP_ID" : 8260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8254",
        "source" : "8252",
        "target" : "7804",
        "EdgeBetweenness" : 192.0,
        "shared_name" : "damn (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "damn (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8254,
        "BEND_MAP_ID" : 8254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8248",
        "source" : "8246",
        "target" : "7804",
        "EdgeBetweenness" : 194.0,
        "shared_name" : "different (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "different (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8248,
        "BEND_MAP_ID" : 8248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8244",
        "source" : "8242",
        "target" : "7804",
        "EdgeBetweenness" : 196.0,
        "shared_name" : "donnnn (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "donnnn (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8244,
        "BEND_MAP_ID" : 8244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8240",
        "source" : "8238",
        "target" : "7804",
        "EdgeBetweenness" : 198.0,
        "shared_name" : "sound (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sound (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8240,
        "BEND_MAP_ID" : 8240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8218",
        "source" : "8216",
        "target" : "7804",
        "EdgeBetweenness" : 202.0,
        "shared_name" : "sharp (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sharp (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8218,
        "BEND_MAP_ID" : 8218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8262",
        "source" : "8208",
        "target" : "7804",
        "EdgeBetweenness" : 204.0,
        "shared_name" : "simple (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "simple (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8262,
        "BEND_MAP_ID" : 8262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8210",
        "source" : "8208",
        "target" : "7804",
        "EdgeBetweenness" : 204.0,
        "shared_name" : "simple (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "simple (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8210,
        "BEND_MAP_ID" : 8210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8504",
        "source" : "8204",
        "target" : "7804",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "cold (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cold (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8504,
        "BEND_MAP_ID" : 8504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8206",
        "source" : "8204",
        "target" : "7804",
        "EdgeBetweenness" : 206.0,
        "shared_name" : "cold (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cold (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8206,
        "BEND_MAP_ID" : 8206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8200",
        "source" : "8198",
        "target" : "7804",
        "EdgeBetweenness" : 208.0,
        "shared_name" : "proud (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "proud (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8200,
        "BEND_MAP_ID" : 8200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8196",
        "source" : "8194",
        "target" : "7804",
        "EdgeBetweenness" : 210.0,
        "shared_name" : "disrespectful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "disrespectful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8196,
        "BEND_MAP_ID" : 8196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8990",
        "source" : "8188",
        "target" : "7804",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "young (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "young (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8990,
        "BEND_MAP_ID" : 8990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8690",
        "source" : "8188",
        "target" : "7804",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "young (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "young (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8690,
        "BEND_MAP_ID" : 8690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8190",
        "source" : "8188",
        "target" : "7804",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "young (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "young (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8190,
        "BEND_MAP_ID" : 8190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8186",
        "source" : "8184",
        "target" : "7804",
        "EdgeBetweenness" : 214.0,
        "shared_name" : "patient (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "patient (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8186,
        "BEND_MAP_ID" : 8186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9094",
        "source" : "8180",
        "target" : "7804",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "next (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "next (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9094,
        "BEND_MAP_ID" : 9094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8980",
        "source" : "8180",
        "target" : "7804",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "next (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "next (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8980,
        "BEND_MAP_ID" : 8980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8182",
        "source" : "8180",
        "target" : "7804",
        "EdgeBetweenness" : 216.0,
        "shared_name" : "next (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "next (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8182,
        "BEND_MAP_ID" : 8182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9012",
        "source" : "8174",
        "target" : "7804",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "much (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9012,
        "BEND_MAP_ID" : 9012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8904",
        "source" : "8174",
        "target" : "7804",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "much (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8904,
        "BEND_MAP_ID" : 8904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8896",
        "source" : "8174",
        "target" : "7804",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "much (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8896,
        "BEND_MAP_ID" : 8896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8272",
        "source" : "8174",
        "target" : "7804",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "much (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8272,
        "BEND_MAP_ID" : 8272,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8176",
        "source" : "8174",
        "target" : "7804",
        "EdgeBetweenness" : 1.0,
        "shared_name" : "much (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "much (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8176,
        "BEND_MAP_ID" : 8176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8178",
        "source" : "8170",
        "target" : "7804",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "expensive (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "expensive (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8178,
        "BEND_MAP_ID" : 8178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8172",
        "source" : "8170",
        "target" : "7804",
        "EdgeBetweenness" : 3.0,
        "shared_name" : "expensive (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "expensive (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8172,
        "BEND_MAP_ID" : 8172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8166",
        "source" : "8164",
        "target" : "7804",
        "EdgeBetweenness" : 4.0,
        "shared_name" : "honest (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "honest (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8166,
        "BEND_MAP_ID" : 8166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8156",
        "source" : "8154",
        "target" : "7804",
        "EdgeBetweenness" : 7.0,
        "shared_name" : "hilarious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "hilarious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8156,
        "BEND_MAP_ID" : 8156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8148",
        "source" : "8146",
        "target" : "7804",
        "EdgeBetweenness" : 10.0,
        "shared_name" : "secondary (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "secondary (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8148,
        "BEND_MAP_ID" : 8148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8144",
        "source" : "8142",
        "target" : "7804",
        "EdgeBetweenness" : 11.0,
        "shared_name" : "painful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "painful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8144,
        "BEND_MAP_ID" : 8144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8138",
        "source" : "8136",
        "target" : "7804",
        "EdgeBetweenness" : 13.0,
        "shared_name" : "former (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "former (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8138,
        "BEND_MAP_ID" : 8138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8134",
        "source" : "8132",
        "target" : "7804",
        "EdgeBetweenness" : 14.0,
        "shared_name" : "alive (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "alive (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8134,
        "BEND_MAP_ID" : 8134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8128",
        "source" : "8126",
        "target" : "7804",
        "EdgeBetweenness" : 15.0,
        "shared_name" : "axe (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "axe (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8128,
        "BEND_MAP_ID" : 8128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8120",
        "source" : "8118",
        "target" : "7804",
        "EdgeBetweenness" : 16.0,
        "shared_name" : "Most (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "Most (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8120,
        "BEND_MAP_ID" : 8120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8790",
        "source" : "8112",
        "target" : "7804",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "high (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "high (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8790,
        "BEND_MAP_ID" : 8790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8734",
        "source" : "8112",
        "target" : "7804",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "high (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "high (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8734,
        "BEND_MAP_ID" : 8734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8724",
        "source" : "8112",
        "target" : "7804",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "high (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "high (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8724,
        "BEND_MAP_ID" : 8724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8116",
        "source" : "8112",
        "target" : "7804",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "high (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "high (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8116,
        "BEND_MAP_ID" : 8116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8114",
        "source" : "8112",
        "target" : "7804",
        "EdgeBetweenness" : 18.0,
        "shared_name" : "high (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "high (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8114,
        "BEND_MAP_ID" : 8114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8110",
        "source" : "8108",
        "target" : "7804",
        "EdgeBetweenness" : 19.0,
        "shared_name" : "dead (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "dead (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8110,
        "BEND_MAP_ID" : 8110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8106",
        "source" : "8104",
        "target" : "7804",
        "EdgeBetweenness" : 21.0,
        "shared_name" : "interesting (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "interesting (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8106,
        "BEND_MAP_ID" : 8106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8564",
        "source" : "8098",
        "target" : "7804",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "special (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "special (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8564,
        "BEND_MAP_ID" : 8564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8342",
        "source" : "8098",
        "target" : "7804",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "special (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "special (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8342,
        "BEND_MAP_ID" : 8342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8340",
        "source" : "8098",
        "target" : "7804",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "special (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "special (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8340,
        "BEND_MAP_ID" : 8340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8228",
        "source" : "8098",
        "target" : "7804",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "special (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "special (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8228,
        "BEND_MAP_ID" : 8228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8100",
        "source" : "8098",
        "target" : "7804",
        "EdgeBetweenness" : 23.0,
        "shared_name" : "special (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "special (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8100,
        "BEND_MAP_ID" : 8100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8160",
        "source" : "8092",
        "target" : "7804",
        "EdgeBetweenness" : 26.0,
        "shared_name" : "normal (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "normal (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8160,
        "BEND_MAP_ID" : 8160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8150",
        "source" : "8092",
        "target" : "7804",
        "EdgeBetweenness" : 26.0,
        "shared_name" : "normal (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "normal (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8150,
        "BEND_MAP_ID" : 8150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8094",
        "source" : "8092",
        "target" : "7804",
        "EdgeBetweenness" : 26.0,
        "shared_name" : "normal (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "normal (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8094,
        "BEND_MAP_ID" : 8094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8864",
        "source" : "8086",
        "target" : "7804",
        "EdgeBetweenness" : 28.0,
        "shared_name" : "stupid (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "stupid (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8864,
        "BEND_MAP_ID" : 8864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8088",
        "source" : "8086",
        "target" : "7804",
        "EdgeBetweenness" : 28.0,
        "shared_name" : "stupid (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "stupid (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8088,
        "BEND_MAP_ID" : 8088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8638",
        "source" : "8082",
        "target" : "7804",
        "EdgeBetweenness" : 29.0,
        "shared_name" : "nervous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "nervous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8638,
        "BEND_MAP_ID" : 8638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8084",
        "source" : "8082",
        "target" : "7804",
        "EdgeBetweenness" : 29.0,
        "shared_name" : "nervous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "nervous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8084,
        "BEND_MAP_ID" : 8084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8080",
        "source" : "8078",
        "target" : "7804",
        "EdgeBetweenness" : 31.0,
        "shared_name" : "actual (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "actual (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8080,
        "BEND_MAP_ID" : 8080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9020",
        "source" : "8072",
        "target" : "7804",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "long (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "long (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9020,
        "BEND_MAP_ID" : 9020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8900",
        "source" : "8072",
        "target" : "7804",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "long (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "long (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8900,
        "BEND_MAP_ID" : 8900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8698",
        "source" : "8072",
        "target" : "7804",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "long (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "long (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8698,
        "BEND_MAP_ID" : 8698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8074",
        "source" : "8072",
        "target" : "7804",
        "EdgeBetweenness" : 34.0,
        "shared_name" : "long (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "long (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8074,
        "BEND_MAP_ID" : 8074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8066",
        "source" : "8064",
        "target" : "7804",
        "EdgeBetweenness" : 37.0,
        "shared_name" : "cruel (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cruel (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8066,
        "BEND_MAP_ID" : 8066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8062",
        "source" : "8060",
        "target" : "7804",
        "EdgeBetweenness" : 39.0,
        "shared_name" : "correct (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "correct (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8062,
        "BEND_MAP_ID" : 8062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8902",
        "source" : "8056",
        "target" : "7804",
        "EdgeBetweenness" : 41.0,
        "shared_name" : "last (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "last (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8902,
        "BEND_MAP_ID" : 8902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8058",
        "source" : "8056",
        "target" : "7804",
        "EdgeBetweenness" : 41.0,
        "shared_name" : "last (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "last (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8058,
        "BEND_MAP_ID" : 8058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8818",
        "source" : "8050",
        "target" : "7804",
        "EdgeBetweenness" : 42.0,
        "shared_name" : "cool (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cool (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8818,
        "BEND_MAP_ID" : 8818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8052",
        "source" : "8050",
        "target" : "7804",
        "EdgeBetweenness" : 42.0,
        "shared_name" : "cool (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cool (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8052,
        "BEND_MAP_ID" : 8052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8388",
        "source" : "8046",
        "target" : "7804",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "mysterious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mysterious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8388,
        "BEND_MAP_ID" : 8388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8158",
        "source" : "8046",
        "target" : "7804",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "mysterious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mysterious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8158,
        "BEND_MAP_ID" : 8158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8048",
        "source" : "8046",
        "target" : "7804",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "mysterious (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "mysterious (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8048,
        "BEND_MAP_ID" : 8048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8422",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8422,
        "BEND_MAP_ID" : 8422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8420",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8420,
        "BEND_MAP_ID" : 8420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8338",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8338,
        "BEND_MAP_ID" : 8338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8336",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8336,
        "BEND_MAP_ID" : 8336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8334",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8334,
        "BEND_MAP_ID" : 8334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8256",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8256,
        "BEND_MAP_ID" : 8256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8090",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8090,
        "BEND_MAP_ID" : 8090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8044",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8044,
        "BEND_MAP_ID" : 8044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8042",
        "source" : "8040",
        "target" : "7804",
        "EdgeBetweenness" : 47.0,
        "shared_name" : "weird (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "weird (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8042,
        "BEND_MAP_ID" : 8042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8364",
        "source" : "8026",
        "target" : "7804",
        "EdgeBetweenness" : 49.0,
        "shared_name" : "key (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "key (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8364,
        "BEND_MAP_ID" : 8364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8028",
        "source" : "8026",
        "target" : "7804",
        "EdgeBetweenness" : 49.0,
        "shared_name" : "key (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "key (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8028,
        "BEND_MAP_ID" : 8028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8792",
        "source" : "8022",
        "target" : "7804",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "entire (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "entire (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8792,
        "BEND_MAP_ID" : 8792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8788",
        "source" : "8022",
        "target" : "7804",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "entire (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "entire (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8788,
        "BEND_MAP_ID" : 8788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8718",
        "source" : "8022",
        "target" : "7804",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "entire (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "entire (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8718,
        "BEND_MAP_ID" : 8718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8024",
        "source" : "8022",
        "target" : "7804",
        "EdgeBetweenness" : 53.0,
        "shared_name" : "entire (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "entire (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8024,
        "BEND_MAP_ID" : 8024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8020",
        "source" : "8018",
        "target" : "7804",
        "EdgeBetweenness" : 55.0,
        "shared_name" : "frequent (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "frequent (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8020,
        "BEND_MAP_ID" : 8020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8920",
        "source" : "8014",
        "target" : "7804",
        "EdgeBetweenness" : 58.0,
        "shared_name" : "ridiculous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "ridiculous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8920,
        "BEND_MAP_ID" : 8920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8886",
        "source" : "8014",
        "target" : "7804",
        "EdgeBetweenness" : 58.0,
        "shared_name" : "ridiculous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "ridiculous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8886,
        "BEND_MAP_ID" : 8886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8016",
        "source" : "8014",
        "target" : "7804",
        "EdgeBetweenness" : 58.0,
        "shared_name" : "ridiculous (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "ridiculous (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8016,
        "BEND_MAP_ID" : 8016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9038",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9038,
        "BEND_MAP_ID" : 9038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8906",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8906,
        "BEND_MAP_ID" : 8906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8738",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8738,
        "BEND_MAP_ID" : 8738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8634",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8634,
        "BEND_MAP_ID" : 8634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8168",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8168,
        "BEND_MAP_ID" : 8168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8010",
        "source" : "8008",
        "target" : "7804",
        "EdgeBetweenness" : 61.0,
        "shared_name" : "great (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "great (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8010,
        "BEND_MAP_ID" : 8010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8982",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8982,
        "BEND_MAP_ID" : 8982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8888",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8888,
        "BEND_MAP_ID" : 8888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8712",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8712,
        "BEND_MAP_ID" : 8712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8552",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8552,
        "BEND_MAP_ID" : 8552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8440",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8440,
        "BEND_MAP_ID" : 8440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8370",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8370,
        "BEND_MAP_ID" : 8370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8226",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8226,
        "BEND_MAP_ID" : 8226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8224",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8224,
        "BEND_MAP_ID" : 8224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8222",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8222,
        "BEND_MAP_ID" : 8222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8220",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8220,
        "BEND_MAP_ID" : 8220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8214",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8214,
        "BEND_MAP_ID" : 8214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8012",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8012,
        "BEND_MAP_ID" : 8012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8006",
        "source" : "8004",
        "target" : "7804",
        "EdgeBetweenness" : 63.0,
        "shared_name" : "many (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "many (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8006,
        "BEND_MAP_ID" : 8006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8002",
        "source" : "8000",
        "target" : "7804",
        "EdgeBetweenness" : 65.0,
        "shared_name" : "dreadful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "dreadful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8002,
        "BEND_MAP_ID" : 8002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8972",
        "source" : "7996",
        "target" : "7804",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "terrible (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "terrible (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8972,
        "BEND_MAP_ID" : 8972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8970",
        "source" : "7996",
        "target" : "7804",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "terrible (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "terrible (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8970,
        "BEND_MAP_ID" : 8970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8530",
        "source" : "7996",
        "target" : "7804",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "terrible (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "terrible (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8530,
        "BEND_MAP_ID" : 8530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7998",
        "source" : "7996",
        "target" : "7804",
        "EdgeBetweenness" : 68.0,
        "shared_name" : "terrible (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "terrible (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7998,
        "BEND_MAP_ID" : 7998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8250",
        "source" : "7990",
        "target" : "7804",
        "EdgeBetweenness" : 70.0,
        "shared_name" : "nice (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "nice (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8250,
        "BEND_MAP_ID" : 8250,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7992",
        "source" : "7990",
        "target" : "7804",
        "EdgeBetweenness" : 70.0,
        "shared_name" : "nice (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "nice (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7992,
        "BEND_MAP_ID" : 7992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7988",
        "source" : "7986",
        "target" : "7804",
        "EdgeBetweenness" : 72.0,
        "shared_name" : "gigantic (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "gigantic (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7988,
        "BEND_MAP_ID" : 7988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8646",
        "source" : "7982",
        "target" : "7804",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "wonderful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wonderful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8646,
        "BEND_MAP_ID" : 8646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8372",
        "source" : "7982",
        "target" : "7804",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "wonderful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wonderful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8372,
        "BEND_MAP_ID" : 8372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7984",
        "source" : "7982",
        "target" : "7804",
        "EdgeBetweenness" : 73.0,
        "shared_name" : "wonderful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "wonderful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7984,
        "BEND_MAP_ID" : 7984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7980",
        "source" : "7978",
        "target" : "7804",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "straight (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "straight (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7980,
        "BEND_MAP_ID" : 7980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8874",
        "source" : "7974",
        "target" : "7804",
        "EdgeBetweenness" : 78.0,
        "shared_name" : "strong (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "strong (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8874,
        "BEND_MAP_ID" : 8874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7976",
        "source" : "7974",
        "target" : "7804",
        "EdgeBetweenness" : 78.0,
        "shared_name" : "strong (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "strong (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7976,
        "BEND_MAP_ID" : 7976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8102",
        "source" : "7970",
        "target" : "7804",
        "EdgeBetweenness" : 80.0,
        "shared_name" : "big (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "big (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8102,
        "BEND_MAP_ID" : 8102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7972",
        "source" : "7970",
        "target" : "7804",
        "EdgeBetweenness" : 80.0,
        "shared_name" : "big (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "big (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7972,
        "BEND_MAP_ID" : 7972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9084",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9084,
        "BEND_MAP_ID" : 9084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9064",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9064,
        "BEND_MAP_ID" : 9064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8642",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8642,
        "BEND_MAP_ID" : 8642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8544",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8544,
        "BEND_MAP_ID" : 8544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8542",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8542,
        "BEND_MAP_ID" : 8542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8446",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8446,
        "BEND_MAP_ID" : 8446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8192",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8192,
        "BEND_MAP_ID" : 8192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8038",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8038,
        "BEND_MAP_ID" : 8038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8036",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8036,
        "BEND_MAP_ID" : 8036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8034",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8034,
        "BEND_MAP_ID" : 8034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8032",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8032,
        "BEND_MAP_ID" : 8032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8030",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8030,
        "BEND_MAP_ID" : 8030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7968",
        "source" : "7966",
        "target" : "7804",
        "EdgeBetweenness" : 83.0,
        "shared_name" : "old (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "old (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7968,
        "BEND_MAP_ID" : 7968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7964",
        "source" : "7960",
        "target" : "7804",
        "EdgeBetweenness" : 85.0,
        "shared_name" : "crazy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "crazy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7964,
        "BEND_MAP_ID" : 7964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7962",
        "source" : "7960",
        "target" : "7804",
        "EdgeBetweenness" : 85.0,
        "shared_name" : "crazy (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "crazy (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7962,
        "BEND_MAP_ID" : 7962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7958",
        "source" : "7956",
        "target" : "7804",
        "EdgeBetweenness" : 87.0,
        "shared_name" : "glad (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "glad (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7958,
        "BEND_MAP_ID" : 7958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8956",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8956,
        "BEND_MAP_ID" : 8956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8764",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8764,
        "BEND_MAP_ID" : 8764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8310",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8310,
        "BEND_MAP_ID" : 8310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8290",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8290,
        "BEND_MAP_ID" : 8290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8202",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8202,
        "BEND_MAP_ID" : 8202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8130",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8130,
        "BEND_MAP_ID" : 8130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8122",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8122,
        "BEND_MAP_ID" : 8122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7954",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7954,
        "BEND_MAP_ID" : 7954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7950",
        "source" : "7948",
        "target" : "7804",
        "EdgeBetweenness" : 92.0,
        "shared_name" : "good (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "good (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7950,
        "BEND_MAP_ID" : 7950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8344",
        "source" : "7944",
        "target" : "7804",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "new (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "new (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8344,
        "BEND_MAP_ID" : 8344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8096",
        "source" : "7944",
        "target" : "7804",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "new (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "new (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8096,
        "BEND_MAP_ID" : 8096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7946",
        "source" : "7944",
        "target" : "7804",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "new (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "new (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7946,
        "BEND_MAP_ID" : 7946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7940",
        "source" : "7938",
        "target" : "7804",
        "EdgeBetweenness" : 96.0,
        "shared_name" : "unyielding (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "unyielding (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7940,
        "BEND_MAP_ID" : 7940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8658",
        "source" : "7934",
        "target" : "7804",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "certain (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "certain (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8658,
        "BEND_MAP_ID" : 8658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7936",
        "source" : "7934",
        "target" : "7804",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "certain (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "certain (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7936,
        "BEND_MAP_ID" : 7936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7932",
        "source" : "7930",
        "target" : "7804",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "tall (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "tall (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7932,
        "BEND_MAP_ID" : 7932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9082",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9082,
        "BEND_MAP_ID" : 9082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9078",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9078,
        "BEND_MAP_ID" : 9078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9068",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9068,
        "BEND_MAP_ID" : 9068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9062",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9062,
        "BEND_MAP_ID" : 9062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9010",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9010,
        "BEND_MAP_ID" : 9010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8854",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8854,
        "BEND_MAP_ID" : 8854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8848",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8848,
        "BEND_MAP_ID" : 8848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8774",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8774,
        "BEND_MAP_ID" : 8774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8650",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8650,
        "BEND_MAP_ID" : 8650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8636",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8636,
        "BEND_MAP_ID" : 8636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8574",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8574,
        "BEND_MAP_ID" : 8574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8434",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8434,
        "BEND_MAP_ID" : 8434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8326",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8326,
        "BEND_MAP_ID" : 8326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7952",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7952,
        "BEND_MAP_ID" : 7952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7942",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7942,
        "BEND_MAP_ID" : 7942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7928",
        "source" : "7926",
        "target" : "7804",
        "EdgeBetweenness" : 102.0,
        "shared_name" : "right (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "right (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7928,
        "BEND_MAP_ID" : 7928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7924",
        "source" : "7922",
        "target" : "7804",
        "EdgeBetweenness" : 105.0,
        "shared_name" : "final (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "final (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7924,
        "BEND_MAP_ID" : 7924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8914",
        "source" : "7918",
        "target" : "7804",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "careful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "careful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8914,
        "BEND_MAP_ID" : 8914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8304",
        "source" : "7918",
        "target" : "7804",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "careful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "careful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8304,
        "BEND_MAP_ID" : 8304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8232",
        "source" : "7918",
        "target" : "7804",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "careful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "careful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8232,
        "BEND_MAP_ID" : 8232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7920",
        "source" : "7918",
        "target" : "7804",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "careful (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "careful (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7920,
        "BEND_MAP_ID" : 7920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7916",
        "source" : "7914",
        "target" : "7804",
        "EdgeBetweenness" : 110.0,
        "shared_name" : "sudden (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sudden (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7916,
        "BEND_MAP_ID" : 7916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8682",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8682,
        "BEND_MAP_ID" : 8682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8680",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8680,
        "BEND_MAP_ID" : 8680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8640",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8640,
        "BEND_MAP_ID" : 8640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8588",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8588,
        "BEND_MAP_ID" : 8588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8488",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8488,
        "BEND_MAP_ID" : 8488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8472",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8472,
        "BEND_MAP_ID" : 8472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8152",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8152,
        "BEND_MAP_ID" : 8152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7994",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7994,
        "BEND_MAP_ID" : 7994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7912",
        "source" : "7910",
        "target" : "7804",
        "EdgeBetweenness" : 113.0,
        "shared_name" : "little (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "little (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7912,
        "BEND_MAP_ID" : 7912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7908",
        "source" : "7906",
        "target" : "7804",
        "EdgeBetweenness" : 114.0,
        "shared_name" : "favorite (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "favorite (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7908,
        "BEND_MAP_ID" : 7908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8838",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8838,
        "BEND_MAP_ID" : 8838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8736",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8736,
        "BEND_MAP_ID" : 8736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8514",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8514,
        "BEND_MAP_ID" : 8514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8452",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8452,
        "BEND_MAP_ID" : 8452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8378",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8378,
        "BEND_MAP_ID" : 8378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8234",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8234,
        "BEND_MAP_ID" : 8234,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8230",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8230,
        "BEND_MAP_ID" : 8230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7904",
        "source" : "7902",
        "target" : "7804",
        "EdgeBetweenness" : 117.0,
        "shared_name" : "first (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "first (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7904,
        "BEND_MAP_ID" : 7904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7900",
        "source" : "7898",
        "target" : "7804",
        "EdgeBetweenness" : 119.0,
        "shared_name" : "legendary (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "legendary (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7900,
        "BEND_MAP_ID" : 7900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9086",
        "source" : "7894",
        "target" : "7804",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "more (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9086,
        "BEND_MAP_ID" : 9086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9058",
        "source" : "7894",
        "target" : "7804",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "more (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9058,
        "BEND_MAP_ID" : 9058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8568",
        "source" : "7894",
        "target" : "7804",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "more (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8568,
        "BEND_MAP_ID" : 8568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8454",
        "source" : "7894",
        "target" : "7804",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "more (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8454,
        "BEND_MAP_ID" : 8454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7896",
        "source" : "7894",
        "target" : "7804",
        "EdgeBetweenness" : 121.0,
        "shared_name" : "more (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "more (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7896,
        "BEND_MAP_ID" : 7896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7892",
        "source" : "7890",
        "target" : "7804",
        "EdgeBetweenness" : 123.0,
        "shared_name" : "pointless (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "pointless (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7892,
        "BEND_MAP_ID" : 7892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7888",
        "source" : "7886",
        "target" : "7804",
        "EdgeBetweenness" : 125.0,
        "shared_name" : "decorative (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "decorative (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7888,
        "BEND_MAP_ID" : 7888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7884",
        "source" : "7882",
        "target" : "7804",
        "EdgeBetweenness" : 128.0,
        "shared_name" : "deep (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "deep (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7884,
        "BEND_MAP_ID" : 7884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8236",
        "source" : "7878",
        "target" : "7804",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "real (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "real (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8236,
        "BEND_MAP_ID" : 8236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8124",
        "source" : "7878",
        "target" : "7804",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "real (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "real (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8124,
        "BEND_MAP_ID" : 8124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8070",
        "source" : "7878",
        "target" : "7804",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "real (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "real (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8070,
        "BEND_MAP_ID" : 8070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8068",
        "source" : "7878",
        "target" : "7804",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "real (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "real (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8068,
        "BEND_MAP_ID" : 8068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7880",
        "source" : "7878",
        "target" : "7804",
        "EdgeBetweenness" : 130.0,
        "shared_name" : "real (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "real (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7880,
        "BEND_MAP_ID" : 7880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7876",
        "source" : "7874",
        "target" : "7804",
        "EdgeBetweenness" : 132.0,
        "shared_name" : "o:[decorative (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "o:[decorative (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7876,
        "BEND_MAP_ID" : 7876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7872",
        "source" : "7870",
        "target" : "7804",
        "EdgeBetweenness" : 134.0,
        "shared_name" : "fine (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "fine (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7872,
        "BEND_MAP_ID" : 7872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7868",
        "source" : "7866",
        "target" : "7804",
        "EdgeBetweenness" : 136.0,
        "shared_name" : "chinese (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "chinese (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7868,
        "BEND_MAP_ID" : 7868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9022",
        "source" : "7862",
        "target" : "7804",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "full (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "full (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9022,
        "BEND_MAP_ID" : 9022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9004",
        "source" : "7862",
        "target" : "7804",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "full (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "full (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9004,
        "BEND_MAP_ID" : 9004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7864",
        "source" : "7862",
        "target" : "7804",
        "EdgeBetweenness" : 137.0,
        "shared_name" : "full (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "full (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7864,
        "BEND_MAP_ID" : 7864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8494",
        "source" : "7858",
        "target" : "7804",
        "EdgeBetweenness" : 139.0,
        "shared_name" : "funny (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "funny (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8494,
        "BEND_MAP_ID" : 8494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7860",
        "source" : "7858",
        "target" : "7804",
        "EdgeBetweenness" : 139.0,
        "shared_name" : "funny (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "funny (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7860,
        "BEND_MAP_ID" : 7860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7856",
        "source" : "7854",
        "target" : "7804",
        "EdgeBetweenness" : 141.0,
        "shared_name" : "cut (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cut (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7856,
        "BEND_MAP_ID" : 7856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9054",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9054,
        "BEND_MAP_ID" : 9054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8890",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8890,
        "BEND_MAP_ID" : 8890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8696",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8696,
        "BEND_MAP_ID" : 8696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8598",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8598,
        "BEND_MAP_ID" : 8598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8546",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8546,
        "BEND_MAP_ID" : 8546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8532",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8532,
        "BEND_MAP_ID" : 8532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8508",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8508,
        "BEND_MAP_ID" : 8508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8478",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8478,
        "BEND_MAP_ID" : 8478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8358",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8358,
        "BEND_MAP_ID" : 8358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8212",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8212,
        "BEND_MAP_ID" : 8212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8140",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8140,
        "BEND_MAP_ID" : 8140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8076",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8076,
        "BEND_MAP_ID" : 8076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7852",
        "source" : "7850",
        "target" : "7804",
        "EdgeBetweenness" : 144.0,
        "shared_name" : "same (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "same (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7852,
        "BEND_MAP_ID" : 7852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8892",
        "source" : "7846",
        "target" : "7804",
        "EdgeBetweenness" : 147.0,
        "shared_name" : "short (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "short (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8892,
        "BEND_MAP_ID" : 8892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8516",
        "source" : "7846",
        "target" : "7804",
        "EdgeBetweenness" : 147.0,
        "shared_name" : "short (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "short (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8516,
        "BEND_MAP_ID" : 8516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7848",
        "source" : "7846",
        "target" : "7804",
        "EdgeBetweenness" : 147.0,
        "shared_name" : "short (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "short (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7848,
        "BEND_MAP_ID" : 7848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7844",
        "source" : "7842",
        "target" : "7804",
        "EdgeBetweenness" : 148.0,
        "shared_name" : "main (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "main (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7844,
        "BEND_MAP_ID" : 7844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8424",
        "source" : "7838",
        "target" : "7804",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "cute (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cute (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8424,
        "BEND_MAP_ID" : 8424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8328",
        "source" : "7838",
        "target" : "7804",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "cute (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cute (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8328,
        "BEND_MAP_ID" : 8328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7840",
        "source" : "7838",
        "target" : "7804",
        "EdgeBetweenness" : 152.0,
        "shared_name" : "cute (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "cute (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7840,
        "BEND_MAP_ID" : 7840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8908",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8908,
        "BEND_MAP_ID" : 8908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8844",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8844,
        "BEND_MAP_ID" : 8844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8840",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8840,
        "BEND_MAP_ID" : 8840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8406",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8406,
        "BEND_MAP_ID" : 8406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8162",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8162,
        "BEND_MAP_ID" : 8162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8054",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8054,
        "BEND_MAP_ID" : 8054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7836",
        "source" : "7834",
        "target" : "7804",
        "EdgeBetweenness" : 155.0,
        "shared_name" : "other (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "other (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7836,
        "BEND_MAP_ID" : 7836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8648",
        "source" : "7830",
        "target" : "7804",
        "EdgeBetweenness" : 157.0,
        "shared_name" : "upper (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "upper (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8648,
        "BEND_MAP_ID" : 8648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7832",
        "source" : "7830",
        "target" : "7804",
        "EdgeBetweenness" : 157.0,
        "shared_name" : "upper (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "upper (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7832,
        "BEND_MAP_ID" : 7832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7828",
        "source" : "7826",
        "target" : "7804",
        "EdgeBetweenness" : 158.0,
        "shared_name" : "bottom (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "bottom (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7828,
        "BEND_MAP_ID" : 7828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "8926",
        "source" : "7822",
        "target" : "7804",
        "EdgeBetweenness" : 160.0,
        "shared_name" : "small (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "small (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 8926,
        "BEND_MAP_ID" : 8926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7824",
        "source" : "7822",
        "target" : "7804",
        "EdgeBetweenness" : 160.0,
        "shared_name" : "small (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "small (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7824,
        "BEND_MAP_ID" : 7824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "9014",
        "source" : "7818",
        "target" : "7804",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "whole (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "whole (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 9014,
        "BEND_MAP_ID" : 9014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7820",
        "source" : "7818",
        "target" : "7804",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "whole (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "whole (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7820,
        "BEND_MAP_ID" : 7820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "7816",
        "source" : "7802",
        "target" : "7804",
        "EdgeBetweenness" : 167.0,
        "shared_name" : "sixth (interacts with) ADJ",
        "shared_interaction" : "interacts with",
        "name" : "sixth (interacts with) ADJ",
        "interaction" : "interacts with",
        "SUID" : 7816,
        "BEND_MAP_ID" : 7816,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}